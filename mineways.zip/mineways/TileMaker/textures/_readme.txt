Textures that are useful for Mineways' physically based material system.

water_normal.png - use for the normal map for water_still and water_flow materials. From NVIDIA's open source MDL library: https://www.nvidia.com/en-us/design-visualization/technologies/material-definition-language/