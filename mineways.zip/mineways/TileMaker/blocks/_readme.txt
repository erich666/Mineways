The ChannelMixer command-line application in Mineways copies textures from a Mineways mod to the proper locations and directories here in the "blocks" directory, so that you can make your own terrain files for use in Mineways. See http://mineways.com/textures.html (or docs/textures.html in this local Mineways distribution), under "Introduction to Terrain Files", for how this process works. ChannelMixe will populate these directories here, or can create and populate them elsewhere. To give you a sense of the skeleton structure, I provide the empty directories and _readme.txt files here in case you want to manually add, remove, or edit files in these directories.


This blocks directory is where to put any block image PNG files from your "\assets\minecraft\textures\blocks" directory in a Minecraft resource pack in order to create your own terrainExt.png file, which Mineways' File | Set Terrain File then uses.

If you're doing this manually, you will also want to copy the (rarely seen in-game) barrier.png tile in "\assets\minecraft\textures\item(s)" to this blocks directory. Also, decorated_pot_side.png (but not decorated_pot_base.png) found in "\assets\minecraft\textures\entity\decorated_pot\" is moved to the main "blocks" directory.

There are three subdirectories currently:
	chest
	decorated_pot
	shelf

These are separated because the textures are of unusual sizes.

For chests, the textures are found in your resource pack's "\assets\minecraft\textures\entity\chest" directory. Put the chest images in that directory, such as ender.png, normal.png, normal_left.png, and normal_right.png (or normal_double.png, for resource packs for 1.14 and earlier) into the "chest" subdirectory here.

The decorated pot tile decorated_pot_base.png is normally found in "\assets\minecraft\textures\entity\decorated_pot\" and moved to the "decorated_pot" subdirectory here. Note that "decorated_pot_side.png" is also found there, but is moved to the main "blocks" directory since it is a standard size.

The "shelf" subdirectory is just that, all the "*shelf.png" files such as "acacia_shelf.png" to "warped_shelf.png" for texturing shelves. These are normally found in the "\assets\minecraft\textures\blocks", where most block textures are located. But, these are moved to this subdirectory for convenience, since they are mosaiced textures of non-standard widths.


See mineways.html (textures.html in the docs directory, or http://mineways.com/textures.html) about ChannelMixer and TileMaker for more information.